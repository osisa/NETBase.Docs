﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="o.s.i.s.a. GmbH" file="TestClass.cs">
//    (c) 2014. See licence text in binary folder.
// </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace TestCoreClassLibrary
{
    public class TestClass
    {
        #region Public Properties

        public string TestProperty { get; set; }

        #endregion
    }
}